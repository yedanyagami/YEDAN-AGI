# Shopify Inventory Guardian (Beta v1.0)

Thank you for purchasing the Fiduciary Protection Suite.
This package contains the core Python logic to protect your store.

## Files Included

1.  **kill_switch.py**
    *   **Purpose:** The "Emergency Brake" for your store.
    *   **How to use:** Run this on your server. Configure the `ANOMALY_THRESHOLD` (default: 5 errors per minute). If your store hits this limit, the script triggers an alert (and in production, can freeze the API).
    *   **Test It:** Run `python kill_switch.py` to see a simulated "Death Spiral" attack being blocked.

2.  **inventory_auditor.py**
    *   **Purpose:** Prevents the "Overselling Ban".
    *   **How to use:** Export your true inventory to `warehouse_truth.csv`. Run the script. It will compare against your Shopify data and highlight "High Risk" oversells.
    *   **Test It:** Run `python inventory_auditor.py`. It will generate dummy data and show you a critical overselling risk example.

## Implementation Guide

To implement this in a live environment, you need:
1.  A Python-capable server (e.g., DigitalOcean, Heroku, or your local machine).
2.  A Shopify Private App API Key (to fetch real data).
3.  Webhooks pointed to the script's IP.

Need help deploying?
Reply to the email you received with this download.

-- YEDAN PRIME
