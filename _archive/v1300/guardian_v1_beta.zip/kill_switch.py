"""
GUARDIAN API - KILL SWITCH MODULE (V1.0 BETA)
---------------------------------------------
Use this script to protect your Shopify store from "Death Spirals" 
(infinite loops, mass overselling, or pixel misfires).

CONFIGURATION:
1. Set your thresholds below.
2. Run this script on your server (or locally for testing).
3. Point your Shopify Webhooks to this endpoint (or use the poller).

"""
import time
import logging
from collections import deque
from datetime import datetime

# --- CONFIGURATION ---
ANOMALY_THRESHOLD = 5         # Max 'bad events' allowed
TIME_WINDOW_SECONDS = 60      # In this time window
DANGEROUS_KEYWORDS = [        # Keywords in order tags/notes that signal danger
    "inventory_error", 
    "sync_failed", 
    "oversold",
    "payment_gateway_error"
]
# ---------------------

logging.basicConfig(level=logging.INFO, format='%(asctime)s [GUARDIAN] %(message)s')

class KillSwitch:
    def __init__(self):
        self.risk_counter = deque() # Stores timestamps of bad events
        self.is_active = True
        logging.info("🛡️  Guardian Kill-Switch ACTIVE. Monitoring for anomalies...")

    def log_event(self, event_type, payload):
        """Call this function whenever a webhook is received."""
        if not self.is_active:
            return

        # 1. Analyze Event
        is_dangerous = False
        
        # Check text (simple heuristics for MVP)
        payload_str = str(payload).lower()
        for kw in DANGEROUS_KEYWORDS:
            if kw in payload_str:
                is_dangerous = True
                logging.warning(f"⚠️  Dangerous Keyword Detected: {kw}")
                break
        
        # 2. Update Risk Counter
        if is_dangerous:
            now = time.time()
            self.risk_counter.append(now)
            self._prune_old_events(now)
            
            # 3. Check Threshold
            if len(self.risk_counter) >= ANOMALY_THRESHOLD:
                self.trigger_kill_protocol()

    def _prune_old_events(self, now):
        """Remove events older than the time window."""
        while self.risk_counter and (now - self.risk_counter[0] > TIME_WINDOW_SECONDS):
            self.risk_counter.popleft()

    def trigger_kill_protocol(self):
        """THE NUCLEAR OPTION: Disables the store's ability to process."""
        logging.critical("vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv")
        logging.critical("🚫 KILL SWITCH TRIGGERED! THRESHOLD EXCEEDED")
        logging.critical("^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^")
        
        # IN VERSION 1.0 -> We just Log/Alert.
        # IN PRODUCTION -> You would verify API call to disable the App/Script.
        # example: shopify.ScriptTag.find(id).destroy()
        
        self.is_active = False
        print("\n\n!!! ALARM: AUTOMATION FROZEN TO PREVENT LOSS !!!\n\n")

# --- SIMULATION (FOR USER) ---
if __name__ == "__main__":
    guardian = KillSwitch()
    
    print("--- Simulating 'Death Spiral' Attack ---")
    
    # Simulate normal events
    guardian.log_event("order_create", {"id": 1, "note": "Normal Customer"})
    time.sleep(0.2)
    
    # Simulate Attack (e.g., Infinite Loop Script)
    for i in range(10):
        print(f"Incoming Event {i+1}...")
        guardian.log_event("order_create", {"id": i, "note": "CRITICAL: sync_failed_inventory_error"})
        if not guardian.is_active:
            break
        time.sleep(0.5)
