"""
GUARDIAN API - INVENTORY AUDITOR (V1.0 BETA)
--------------------------------------------
Prevents "Overselling Bans" by cross-referencing your Shopify 
inventory with your Warehouse CSV every 5 minutes.

USAGE:
1. Export your Warehouse stock to 'warehouse_truth.csv'.
2. Run this script.
3. It creates 'diff_report.txt' with required fixes.
"""

import csv
import json
import logging
from datetime import datetime

# CONFIG
VARIANCE_TOLERANCE = 0  # Zero tolerance for errors in beta

def run_audit(shopify_json_path, warehouse_csv_path):
    print(f"[{datetime.now()}] 🔍 Starting Inventory Audit...")
    
    # 1. Load Truth (Warehouse)
    warehouse_stock = {}
    try:
        with open(warehouse_csv_path, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                sku = row.get("SKU")
                qty = int(row.get("QTY", 0))
                if sku:
                    warehouse_stock[sku] = qty
    except FileNotFoundError:
        print("❌ Error: 'warehouse_truth.csv' not found.")
        return

    # 2. Load State (Shopify Simulation)
    # In prod, this would be: requests.get(shopify_url / products.json)
    shopify_stock = {}
    try:
        with open(shopify_json_path, 'r') as f:
            data = json.load(f)
            # Assuming standard Shopify Product JSON structure
            for product in data.get("products", []):
                for variant in product.get("variants", []):
                    sku = variant.get("sku")
                    qty = variant.get("inventory_quantity")
                    if sku:
                        shopify_stock[sku] = qty
    except FileNotFoundError:
        print("❌ Error: 'shopify_export.json' not found.")
        return

    # 3. Compare & Report
    discrepancies = []
    
    all_skus = set(warehouse_stock.keys()) | set(shopify_stock.keys())
    
    for sku in all_skus:
        w_qty = warehouse_stock.get(sku, 0)
        s_qty = shopify_stock.get(sku, 0)
        
        if w_qty != s_qty:
            diff = s_qty - w_qty
            risk = "HIGH" if s_qty > w_qty else "LOW" # High risk if we are selling what we don't have
            
            discrepancies.append({
                "sku": sku,
                "shopify": s_qty,
                "warehouse": w_qty,
                "diff": diff,
                "risk": risk
            })

    # 4. Output
    if discrepancies:
        print(f"⚠️  FOUND {len(discrepancies)} DISCREPANCIES!")
        print(f"{'SKU':<15} | {'SHOPIFY':<8} | {'TRUE':<8} | {'RISK'}")
        print("-" * 45)
        for d in discrepancies:
            print(f"{d['sku']:<15} | {d['shopify']:<8} | {d['warehouse']:<8} | {d['risk']}")
            
        # Specific "Fear Setting" message for user
        high_risk = [d for d in discrepancies if d['risk'] == "HIGH"]
        if high_risk:
            print("\n🚨 CRITICAL: You are overselling items you do not have!")
            print("   Execute sync correction immediately.")
    else:
        print("✅ Inventory is 100% synced. Sleep well.")

# --- DUMMY DATA CREATOR (For First Run) ---
def create_dummy_data():
    with open("warehouse_truth.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["SKU", "QTY"])
        writer.writerow(["TSHIRT-BLK-M", "100"])
        writer.writerow(["TSHIRT-BLK-L", "50"])
        writer.writerow(["HOODIE-RED-S", "0"]) # Out of stock in warehouse
    
    with open("shopify_export.json", "w") as f:
        # Simulate an error: Hoodie still has 5 stock on Shopify!
        json.dump({
            "products": [
                {"variants": [{"sku": "TSHIRT-BLK-M", "inventory_quantity": 100}]},
                {"variants": [{"sku": "TSHIRT-BLK-L", "inventory_quantity": 48}]}, # Desync (Low Risk)
                {"variants": [{"sku": "HOODIE-RED-S", "inventory_quantity": 5}]}   # Desync (HIGH RISK - Oversell)
            ]
        }, f)

if __name__ == "__main__":
    # Create test files if missing
    try:
        open("warehouse_truth.csv")
    except:
        create_dummy_data()
        
    run_audit("shopify_export.json", "warehouse_truth.csv")
